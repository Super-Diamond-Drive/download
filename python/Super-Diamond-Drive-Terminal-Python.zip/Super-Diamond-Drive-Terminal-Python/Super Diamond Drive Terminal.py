import os

def executeCommand(command):
    if command == "set file content":
     path = input("Enter File Path: ")
     content = input("Enter New File Content")
     file = open("files/data/userfiles/" + path, "w")
     file.write(content)
     file.close()
     print("Sucesfully Set Content Of ", path, " to ", content)
    elif command == "get file content":
     path = input("Enter File Path: ")
     if os.path.exists("files/data/userfiles/" + path):
      file = open("files/data/userfiles/" + path, "r")
      print("The Content of ", path, " is ", file.read())
      file.close()
     else:
      print(path, " does not exsist")
    elif command == "delete file":
     path = input("Enter File Path: ")
     if os.path.exists("files/data/userfiles/" + path):
      os.remove("files/data/userfiles/" + path)
      print("Sucesfully Deleted File at ", path)
     else:
      print(path, " does not exsist")
    elif command == "delete folder":
     path = input("Enter Folder Path: ")
     if os.path.exists("files/data/userfiles/" + path):
      if input("WARNING. make sure the folder is empty or else the app will crash. Y is Yes: ") == "Y":
       os.rmdir("files/data/userfiles/" + path)
       print("Sucesfully Deleted Folder at ", path)
     else:
      print(path, " does not exsist")
    elif command == "create folder":
     path = input("Enter Path For New Folder: ")
     if not os.path.exists("files/data/userfiles/" + path):
      os.mkdir("files/data/userfiles/" + path)
      print("Sucesfully Created Folder at ", path)
     else:
      print(path, " already exsist")
    elif command == "create file":
     path = input("Enter Path For New File: ")
     if not os.path.exists("files/data/userfiles/" + path):
      content = input("Enter Content For New File: ")
      file = open("files/data/userfiles/" + path, "x")
      file.write(content)
      file.close()
      print("Sucesfully Created File ", path, " with content ", content)
     else:
      print(path, " already exsist")
    else:
     print("Action Not Found")

    executeCommand(input("Enter Action: "))

executeCommand(input("Enter Action: "))